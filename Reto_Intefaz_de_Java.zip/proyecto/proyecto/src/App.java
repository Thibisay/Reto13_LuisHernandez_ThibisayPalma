import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");
        Scanner sc = new Scanner(System.in);
        Scanner ins = new Scanner(System.in);
        /*
            • desc es una cadena de caracteres que corresponde a la descripción del equipo (CPU, monitor, mouse, teclado, UPS, pen-drive, cámara, impresora, fotocopiadora)
            • ct representa la cantidad de equipos y es un número entero
            • mu representa el costo unitario de adquisición del equipo y es un número real
            • dd es el día de la fecha de la adquisición, número entero de dos dígitos entre 01 y 31
            • mm es el mes de la fecha de la adquisición, número entero de dos dígitos entre 01 y 12
            • aaaa es el año de la fecha de la adquisición, número entero de cuatro dígitos empezando en 1968
            • nf es una cadena de caracteres que corresponde al número de la factura
            • ci es una cadena de caracteres que corresponde a la CI del profesor responsable del equipo
        */
        
        String desc;
        int ct ;
        float mu ;
        int dd ;
        int mm ;
        int aaaa;
        String nf;
        int ci;
       
        try {
            // Crear un objeto File para el archivo
            File archivo = new File("inventario.txt");

            // Comprobar si el archivo existe
            if (!archivo.exists()) {
                // Crear el archivo
                archivo.createNewFile();
                System.out.println("Archivo creado correctamente.");
            } else {
                System.out.println("El archivo ya existe.");
            }

            boolean seguir = false;
            FileWriter escribir = new FileWriter(archivo);
            do{
                int dia = 1234;
                int dia2 = dia / 100;
                System.out.println(dia2);
                dia = dia % 100;
                System.out.println(dia);
                desc = sc.nextLine();
                ct = sc.nextInt();
                mu = sc.nextFloat();
                dd = sc.nextInt();
                mm = sc.nextInt();
                aaaa = sc.nextInt();
                nf = ins.nextLine();
                ci = sc.nextInt();
                
                //Dia no aceptados mayores de 31 y menores que 0

                if(dd > 31 || dd < 0){
                    System.out.println("Dato incorrecto");
                    break;
                }

                //Meses no aceptados mayores que Dic(12) y menores que Enero (1)

                if (mm > 12 || mm < 1){

                    //Caso para feb (2), se toma en consideracon el año bisiesto

                    if(mm == 2 & dd > 29){
                        System.out.println("Dato incorrecto");
                        break;
                    }
                    System.out.println("Dato incorrecto");
                    break;
                }

                //Años menores que 1980

                if (aaaa < 1980){
                    System.out.println("Dato incorrecto");
                    break;
                }

                escribir.write(desc+"#"+ct+"#"+mu+"#"+dd+"#"+mm+"#"+aaaa+"#"+nf+"#"+ci+"#");
                System.out.println("¿desea ingresar otro producto?(yes/no):");
                String respuesta = ins.nextLine();

                // REFINAR las posibles respuestas
                seguir = "yes".equals(respuesta);
                if(seguir == false){
                escribir.close();
                }
                escribir.write("\r\n");
                sc = new Scanner(System.in);
                ins = new Scanner(System.in);

            }while(seguir == true);
            
          

        } catch (IOException e) {
            System.out.println("Error al crear el archivo: " + e.getMessage());
        }
        


    }
    

    
}
